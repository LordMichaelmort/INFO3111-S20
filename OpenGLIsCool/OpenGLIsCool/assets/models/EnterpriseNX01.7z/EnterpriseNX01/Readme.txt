Star trek Enterprise NX01 Refit 3ds model

This model has its own seperate textre that can be found in the texture folder.
There is an additional texture than can be used as the lights overlay. This will 
activate if you load in the NX01-Detail-lights texture from the Lighting texture
button, above the lights tick box on the model control window of 3D Sci-fi Movie Maker 